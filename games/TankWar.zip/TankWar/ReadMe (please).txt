Français :

Ce jeu est le résultat du mélange de deux versions du moteur. On avait fait toute la partie gameplay avec les tanks sur une première version du moteur basique avec simplement des meshes, des collisions simples (qui ne sont pas réellement fonctionnelles, il faut que le tank soit à une rotation de 0, 90, 180, 360 etc. pour que les collisions fonctionnent bien.
La partie menu a été implémentée après sur une nouvelle version du moteur, mais les deux étaient trop différentes pour pouvoir migrer la partie jeu sur le nouveau moteur. J'ai donc compilé le jeu pour avoir son .exe et j'ai fait en sorte de le lancer depuis l'autre .exe dans un thread qui le surveille tant qu'il est ouvert. Si on ferme la fenêtre, on aura le menu principal qui se réouvrira. 

C'est un premier jeu fait en 2 semaines par deux développeurs débutants. Il y a pas mal de problèmes (notamment le spawn sur des objets, ce qui fait reculer les tanks tant qu'ils sont coincés, ou encore les collisions)



English :

This game is the result of combining two versions of the engine. We had developed the entire gameplay section featuring the tanks using an early version of the basic engine, which only included meshes and simple collision detection (which isn’t actually functional; the tank must be rotated to 0, 90, 180, 360 degrees, etc., for the collisions to work properly).
The menu section was implemented later using a new version of the engine, but the two were too different to allow the game section to be migrated to the new engine. So I compiled the game to get its .exe file and arranged for it to be launched from the other .exe in a thread that monitors it whilst it is open. If you close the window, the main menu will reopen. 

This is a first game made in two weeks by two novice developers. There are quite a few issues (notably spawning on objects, which causes tanks to move backwards whilst they’re stuck, or the collision system).